<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");

// 配置
$CONFIG_FILE = './config.json';
$IMG_DIR = "img";
$LOG_DIR = "logs";
$GITEE_URL = "https://ai.gitee.com/v1/images/generations";

// 确保目录存在
foreach ([$IMG_DIR, $LOG_DIR] as $dir) {
    !is_dir($dir) && mkdir($dir, 0777, true);
}

// ========== 日志函数 ==========
function writeHkLog($type, $data) {
    global $LOG_DIR;
    $file = "{$LOG_DIR}/hk_{$type}_" . date('Ymd') . ".log";
    $logStr = date('Y-m-d H:i:s') . " | " . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n";
    file_put_contents($file, $logStr, FILE_APPEND);
}

// ========== 工具函数 ==========
function curlPost($url, $postData, $headers = [], $timeout = 300) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($postData, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $reqHeader = curl_getinfo($ch, CURLINFO_HEADER_OUT);
    curl_close($ch);
    return [
        'code' => $httpCode,
        'data' => json_decode($response, true) ?: $response,
        'request_url' => $url,
        'request_data' => $postData,
        'request_header' => $reqHeader
    ];
}

function deleteImageLater($filePath, $delay = 180) {
    $cmd = "sleep {$delay} && rm -f " . escapeshellarg($filePath) . " > /dev/null 2>&1 &";
    exec($cmd);
}

// ========== 主逻辑 ==========
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    $res = ['code' => -10, 'msg' => '仅支持POST'];
    writeHkLog('error', $res);
    die(json_encode($res));
}

// 1. 记录接收美国端的请求
$rawData = file_get_contents('php://input');
$usaParams = json_decode($rawData, true);
writeHkLog('receive_usa', [
    'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'raw_params' => $rawData,
    'parsed_params' => $usaParams,
    'time' => date('Y-m-d H:i:s')
]);

if (empty($usaParams)) {
    $res = ['code' => -1, 'msg' => '参数为空'];
    writeHkLog('response_usa', $res);
    die(json_encode($res));
}

// 加载润色配置
$polishConf = $usaParams['polish_model'] ?? [];
if (empty($polishConf) && file_exists($CONFIG_FILE)) {
    $localConfig = json_decode(file_get_contents($CONFIG_FILE), true);
    $polishConf = $localConfig['polish_model'] ?? [];
}
if (empty($polishConf)) {
    $res = ['code' => -3, 'msg' => '缺少润色模型配置'];
    writeHkLog('response_usa', $res);
    die(json_encode($res));
}

// 2. 调用润色模型并记录日志
$messages = [
    ["role" => "system", "content" => "你是专业文生图提示词优化师，严格按照用户需求融合人设和聊天记录，{$polishConf['polish_keywords']}，生成细节丰富、符合AI生图标准的提示词，200字内，仅返回提示词，无多余内容"],
    ["role" => "user", "content" => "人设：{$usaParams['personality']}\n聊天记录：{$usaParams['chat_record']}\n原始提示词：{$usaParams['prompt']}\n生成优化提示词"]
];
$postData = [
    "model" => $polishConf['model_name'],
    "messages" => $messages,
    "temperature" => 0.6,
    "max_tokens" => 300
];
$headers = [
    "Content-Type: application/json",
    "Authorization: Bearer {$polishConf['api_key']}"
];
$refineResult = curlPost($polishConf['request_url'], $postData, $headers, $polishConf['request_timeout']);
// 记录润色日志
writeHkLog('polish_model', [
    'request' => $postData,
    'response' => $refineResult,
    'time' => date('Y-m-d H:i:s')
]);

$refinedPrompt = $refineResult['code'] == 200 ? trim($refineResult['data']['choices'][0]['message']['content']) : "{$usaParams['prompt']}，{$usaParams['personality']}风格";

// 3. 调用生图接口并记录日志
$mainProxy = $usaParams['main_proxy'] ?? [];
$apiKey = $mainProxy['api_key'] ?? $usaParams['Authorization'];
$modelName = $mainProxy['model_name'] ?? $usaParams['model'];
$imgPostData = [
    "prompt" => $refinedPrompt,
    "model" => $modelName,
    "size" => $usaParams['size'],
    "response_format" => "url",
    "extra_body" => ["num_inference_steps" => intval($usaParams['num_inference_steps'])]
];
$imgHeaders = [
    "Content-Type: application/json",
    "Authorization: Bearer {$apiKey}"
];
$imgResult = curlPost($GITEE_URL, $imgPostData, $imgHeaders, $usaParams['request_timeout'] ?? 300);
// 记录生图日志
writeHkLog('generate_image', [
    'request' => $imgPostData,
    'response' => $imgResult,
    'refined_prompt' => $refinedPrompt,
    'time' => date('Y-m-d H:i:s')
]);

if ($imgResult['code'] != 200 || empty($imgResult['data']['data'][0]['url'])) {
    $res = ['code' => -1, 'msg' => '生图失败', 'data' => $imgResult];
    writeHkLog('response_usa', $res);
    die(json_encode($res));
}

// 保存图片
$giteeImgUrl = $imgResult['data']['data'][0]['url'];
$ext = pathinfo(parse_url($giteeImgUrl, PHP_URL_PATH), PATHINFO_EXTENSION);
$fileName = "img_" . uniqid() . "." . ($ext ?: 'png');
$localPath = "{$IMG_DIR}/{$fileName}";
$saveSuccess = @file_put_contents($localPath, file_get_contents($giteeImgUrl));
if ($saveSuccess) {
    chmod($localPath, 0666);
    deleteImageLater($localPath);
} else {
    $res = ['code' => -2, 'msg' => '图片保存失败', 'data' => $imgResult];
    writeHkLog('response_usa', $res);
    die(json_encode($res));
}

$localUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . "://{$_SERVER['HTTP_HOST']}/{$localPath}";
$finalRes = [
    "code" => 200,
    "data" => [
        "gitee_url" => $giteeImgUrl,
        "local_url" => $localUrl,
        "original_prompt" => $usaParams['prompt'],
        "refined_prompt" => $refinedPrompt,
        "personality" => $usaParams['personality'],
        "chat_record" => $usaParams['chat_record']
    ]
];

// 4. 记录返回给美国端的响应
writeHkLog('response_usa', [
    'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'response' => $finalRes,
    'time' => date('Y-m-d H:i:s')
]);

echo json_encode($finalRes, JSON_UNESCAPED_UNICODE);
?>
