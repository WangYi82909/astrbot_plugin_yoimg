<?php
// 开启错误显示（调试用，生产环境注释）
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ========== 配置文件路径 ==========
$CONFIG_FILE = './config.json';
$SAVE_FILE = './personality.json';
$DEBUG_LOG = './astrbot_debug.log';

// ========== 加载配置文件函数 ==========
function loadConfig($configPath) {
    if (!file_exists($configPath)) {
        return ['code' => -100, 'msg' => '配置文件不存在'];
    }
    $configContent = file_get_contents($configPath);
    $config = json_decode($configContent, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return ['code' => -101, 'msg' => '配置文件JSON格式错误'];
    }
    $requiredPolishKeys = ['request_url', 'api_key', 'model_name', 'request_timeout'];
    foreach ($requiredPolishKeys as $key) {
        if (empty($config['polish_model'][$key])) {
            return ['code' => -102, 'msg' => "配置文件缺少 polish_model.{$key}"];
        }
    }
    return ['code' => 200, 'data' => $config];
}

// ========== 工具函数：写入调试日志 ==========
function writeDebugLog($msg, $logFile) {
    $log = date('Y-m-d H:i:s') . " | " . $msg . "\n";
    file_put_contents($logFile, $log, FILE_APPEND);
}

// ========== 工具函数：调用润色模型提取关键词 ==========
function extractKeywords($content, $polishConf) {
    $messages = [
        [
            "role" => "system",
            "content" => "提取人设核心信息：性别、年龄、外貌身高、习惯特征，严格控制在200字内，只输出结果"
        ],
        [
            "role" => "user",
            "content" => $content
        ]
    ];

    $postData = [
        "model" => $polishConf['model_name'],
        "messages" => $messages,
        "temperature" => 0.3,
        "max_tokens" => 150,
        "stream" => false
    ];

    $ch = curl_init($polishConf['request_url']);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($postData),
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer {$polishConf['api_key']}"
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $polishConf['request_timeout'],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);

    $response = curl_exec($ch);
    $curlErr = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErr || $httpCode != 200) {
        writeDebugLog("模型调用失败：{$curlErr} (HTTP: {$httpCode})", $GLOBALS['DEBUG_LOG']);
        return "关键词提取失败，请检查配置";
    }

    $modelResult = json_decode($response, true);
    $keywords = trim($modelResult['choices'][0]['message']['content'] ?? '');
    return mb_substr($keywords, 0, 200, 'utf-8');
}

// ========== 主逻辑：统一返回JSON ==========
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");

$response = ['code' => 500, 'msg' => '未知错误', 'data' => []];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取请求数据（兼容表单和JSON）
    $isJson = isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false;
    $input = $isJson ? json_decode(file_get_contents('php://input'), true) : $_POST;

    // 数据校验
    $name = trim($input['name'] ?? '');
    $token = trim($input['token'] ?? '');
    $originalContent = trim($input['original_content'] ?? '');
    $timestamp = $input['timestamp'] ?? date('Y-m-d H:i:s');

    if (empty($name)) {
        $response = ['code' => -1, 'msg' => '人格名称不能为空'];
    } elseif (!preg_match('/^\d{6}$/', $token)) {
        $response = ['code' => -2, 'msg' => 'Token必须是6位数字'];
    } elseif (empty($originalContent)) {
        $response = ['code' => -3, 'msg' => '原始人格描述不能为空'];
    } else {
        // 加载配置
        $configRes = loadConfig($CONFIG_FILE);
        if ($configRes['code'] != 200) {
            $response = $configRes;
        } else {
            $config = $configRes['data'];
            $polishConf = $config['polish_model'];
            $extractedKeywords = extractKeywords($originalContent, $polishConf);

            // 读取并更新人格数据
            $characterData = file_exists($SAVE_FILE) ? json_decode(file_get_contents($SAVE_FILE), true) : [];
            $characterData[$name] = [
                'timestamp' => $timestamp,
                'token' => $token,
                'original_content' => $originalContent,
                'extracted_keywords' => $extractedKeywords,
                'update_time' => date('Y-m-d H:i:s')
            ];

            // 保存文件
            if (file_put_contents($SAVE_FILE, json_encode($characterData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT))) {
                writeDebugLog("人格【{$name}】保存成功", $DEBUG_LOG);
                // 构造成功响应
                $response = [
                    'code' => 200,
                    'data' => [
                        '人设名称' => $name,
                        '提取关键词' => $extractedKeywords
                    ]
                ];
            } else {
                $response = ['code' => -4, 'msg' => '文件写入失败，请检查目录权限'];
            }
        }
    }
} else {
    $response = ['code' => -10, 'msg' => '仅支持POST请求'];
}

// 输出最终响应
echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>
