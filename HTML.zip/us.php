<?php
// 配置文件路径
$CONFIG_FILE = './config.json';
$LOG_FILE = './request.json';
$LOG_DIR = "logs";
$PERSONALITY_FILE = './personality.json';

// 确保日志目录存在
!is_dir($LOG_DIR) && mkdir($LOG_DIR, 0777, true);

// ========== 日志函数 ==========
// 通用日志写入
function writeUsLog($type, $data) {
    global $LOG_DIR;
    $file = "{$LOG_DIR}/usa_{$type}_" . date('Ymd') . ".log";
    $logStr = date('Y-m-d H:i:s') . " | " . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n";
    file_put_contents($file, $logStr, FILE_APPEND);
}

// 写入请求响应汇总日志到request.json
function writeRequestLog($logFile, $reqData, $resData, $success) {
    $logs = ['logs' => []];
    if (file_exists($logFile)) {
        $logContent = file_get_contents($logFile);
        $logs = json_decode($logContent, true) ?: ['logs' => []];
    }
    $logItem = [
        'time' => date('Y-m-d H:i:s'),
        'req' => $reqData,
        'res' => $resData,
        'success' => $success
    ];
    $logs['logs'][] = $logItem;
    file_put_contents($logFile, json_encode($logs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// ========== 配置加载函数 ==========
function loadConfig($configPath) {
    if (!file_exists($configPath)) {
        $err = ['code' => -100, 'msg' => '配置文件不存在'];
        writeUsLog('error', $err);
        die(json_encode($err, JSON_UNESCAPED_UNICODE));
    }
    $configContent = file_get_contents($configPath);
    $config = json_decode($configContent, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $err = ['code' => -101, 'msg' => '配置文件JSON格式错误'];
        writeUsLog('error', $err);
        die(json_encode($err, JSON_UNESCAPED_UNICODE));
    }
    $required = [
        'main_proxy.request_url',
        'main_proxy.api_key',
        'main_proxy.model_name',
        'config_params.request_timeout',
        'config_params.image_size',
        'config_params.image_steps',
        'config_params.guidance_scale',
        'polish_model'
    ];
    foreach ($required as $key) {
        $keys = explode('.', $key);
        $val = $config;
        foreach ($keys as $k) {
            if (!isset($val[$k])) {
                $err = ['code' => -102, 'msg' => "配置文件缺少 {$key}"];
                writeUsLog('error', $err);
                die(json_encode($err, JSON_UNESCAPED_UNICODE));
            }
            $val = $val[$k];
        }
    }
    return $config;
}

// ========== 转发函数 ==========
function forward($url, $params, $timeout) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => json_encode($params),
        CURLOPT_HTTPHEADER => ["Content-Type: application/json"],
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_SSL_VERIFYPEER => 0
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'data' => json_decode($resp, true) ?: $resp];
}

// ========== 主逻辑 ==========
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $res = ['code' => -11, 'msg' => '仅支持POST请求'];
    writeUsLog('response', $res);
    echo json_encode($res);
    exit;
}

// 1. 记录接收的原始请求
$rawData = file_get_contents('php://input');
writeUsLog('receive_request', [
    'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'raw_data' => $rawData,
    'time' => date('Y-m-d H:i:s')
]);

// 解析请求
$inputParams = json_decode($rawData, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    $res = ['code' => -12, 'msg' => 'JSON格式错误'];
    writeUsLog('response', $res);
    echo json_encode($res);
    exit;
}

// 校验必填参数
$requiredInput = ['personality', 'chat_record', 'prompt'];
foreach ($requiredInput as $k) {
    if (!isset($inputParams[$k]) || empty(trim($inputParams[$k]))) {
        $res = ['code' => -13, 'msg' => "缺少必填参数: {$k}"];
        writeUsLog('response', $res);
        echo json_encode($res);
        exit;
    }
}

// 校验人格
$personalityId = trim($inputParams['personality']);
if (!file_exists($PERSONALITY_FILE)) {
    $res = ['code' => -10, 'msg' => '人格需要初始化'];
    writeUsLog('response', $res);
    echo json_encode($res);
    exit;
}
$personalityData = json_decode(file_get_contents($PERSONALITY_FILE), true);
if (!isset($personalityData[$personalityId]) || empty($personalityData[$personalityId]['extracted_keywords'])) {
    $res = ['code' => -10, 'msg' => '人格需要初始化'];
    writeUsLog('response', $res);
    echo json_encode($res);
    exit;
}

// 补全参数
$config = loadConfig($CONFIG_FILE);
$fullParams = [
    'Authorization' => $config['main_proxy']['api_key'],
    'prompt' => trim($inputParams['prompt']),
    'model' => $config['main_proxy']['model_name'],
    'size' => $config['config_params']['image_size'],
    'num_inference_steps' => $config['config_params']['image_steps'],
    'guidance_scale' => $config['config_params']['guidance_scale'],
    'personality' => $personalityData[$personalityId]['extracted_keywords'],
    'chat_record' => trim($inputParams['chat_record'])
];
$fullParams['main_proxy'] = [
    'api_key' => $config['main_proxy']['api_key'],
    'model_name' => $config['main_proxy']['model_name']
];
$fullParams['polish_model'] = $config['polish_model'];

// 记录转发给香港端的请求
writeUsLog('send_to_hk', [
    'hk_url' => $config['main_proxy']['request_url'],
    'params' => $fullParams,
    'time' => date('Y-m-d H:i:s')
]);

// 转发香港端
$HK_URL = $config['main_proxy']['request_url'];
$TIMEOUT = $config['config_params']['request_timeout'];
$result = forward($HK_URL, $fullParams, $TIMEOUT);

// 整理日志和响应
$reqTime = date('Y-m-d H:i:s');
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$reqData = [
    'time' => $reqTime,
    'ip' => $clientIp,
    'params' => [
        'Authorization' => $fullParams['Authorization'],
        'personality' => $fullParams['personality'],
        'chatrecord' => $fullParams['chat_record'],
        'prompt' => $fullParams['prompt'],
        'model' => $fullParams['model'],
        'size' => $fullParams['size']
    ]
];
$resTime = date('Y-m-d H:i:s');
$success = $result['code'] == 200 ? true : false;
$resData = [
    'code' => $result['code'],
    'time' => $resTime,
    'data' => $result['data'] ?? [],
    'msg' => isset($result['data']['msg']) ? $result['data']['msg'] : ($success ? '请求成功' : '香港端请求失败')
];

// 写入汇总日志
writeRequestLog($LOG_FILE, $reqData, $resData, $success);

// 2. 记录发送给调用端的响应
$output = $success ? $result['data'] : ['code' => -101, 'msg' => '香港端请求失败', 'data' => $result];
writeUsLog('send_response', [
    'ip' => $clientIp,
    'response' => $output,
    'time' => date('Y-m-d H:i:s')
]);

echo json_encode($output, JSON_UNESCAPED_UNICODE);
?>
