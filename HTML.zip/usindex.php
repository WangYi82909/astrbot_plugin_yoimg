<?php
$url = "./us.php";
$postData = [
    "personality" => "苏",
        "chat_record" => "无",
            "prompt" => "请结合人设生成"
            ];

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => json_encode($postData), // 转为JSON字符串
                        CURLOPT_HTTPHEADER => [
                                "Content-Type: application/json" // 必须加这个头
                                    ],
                                        CURLOPT_RETURNTRANSFER => true
                                        ]);
                                        $response = curl_exec($ch);
                                        curl_close($ch);
                                        echo $response;
                                        ?>
