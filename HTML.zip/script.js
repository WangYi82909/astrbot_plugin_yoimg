const navLinks = document.querySelectorAll('.sidebar a'), pageSections = document.querySelectorAll('.page-section');
const [mobileMenuBtn, sidebar, mainContent] = [document.getElementById('mobileMenuBtn'), document.getElementById('sidebar'), document.getElementById('mainContent')];
let logsData = [];
// 分页参数
let currentPage = 1;
const pageSize = 10;

// 清除缓存并重置页码
const clearCache = () => {
    logsData = [];
    localStorage.clear();
    currentPage = 1;
    return new Date().getTime();
};

// 侧边栏切换 - 完全保留
navLinks.forEach(link => link.addEventListener('click', e => {
    e.preventDefault();
    const targetId = link.getAttribute('href').slice(1);
    navLinks.forEach(item => item.classList.toggle('active', item === link));
    pageSections.forEach(sec => sec.classList.toggle('active', sec.id === targetId));
    window.innerWidth <= 768 && (sidebar.classList.remove('open'), mainContent.classList.remove('shifted'));
    targetId === 'records' && renderRecords();
}));
mobileMenuBtn.addEventListener('click', () => { 
    sidebar.classList.toggle('open'); 
    mainContent.classList.toggle('shifted'); 
});

// 工具函数 - 简化，适配JSON日志格式
const formatAuth = auth => auth ? auth.slice(0, 6) + '***' : '无';
// 直接解析JSON日志，无需分割文本块
const parseLogs = logJson => {
    if (!logJson || !logJson.logs) return [];
    // 按时间倒序排列，最新的在前面
    return logJson.logs.sort((a, b) => new Date(b.time) - new Date(a.time));
};

const renderRecords = async () => {
    const recordsList = document.getElementById('recordsList');
    if (!recordsList) return;

    const timestamp = clearCache();
    // 1. 先读取人格数据，建立 关键词→人格ID 的映射
    let personalityMap = {};
    try {
        const res = await fetch(`personality.json?t=${timestamp}`);
        if (res.ok) {
            const personalities = await res.json();
            Object.keys(personalities).forEach(id => {
                const keywords = personalities[id].extracted_keywords;
                if (keywords) {
                    personalityMap[keywords.replace(/\s+/g, '')] = id;
                }
            });
        }
    } catch (err) {
        console.log('读取人格数据失败，无法匹配人格ID:', err);
    }

    try {
        const res = await fetch(`request.json?t=${timestamp}`);
        if (!res.ok) throw new Error('日志文件不存在');
        const logJson = await res.json();
        logsData = parseLogs(logJson);
    } catch (err) {
        recordsList.innerHTML = `<div>日志加载失败：${err.message}</div>`;
        return;
    }

    if (!logsData.length) {
        recordsList.innerHTML = '<div>暂无日志记录</div>';
        return;
    }

    const total = logsData.length;
    const totalPages = Math.ceil(total / pageSize);
    const start = (currentPage - 1) * pageSize;
    const end = Math.min(start + pageSize, total);
    const currentLogs = logsData.slice(start, end);

    recordsList.innerHTML = currentLogs.map((log, idx) => {
        const code = log.res?.code || '未知';
        const color = code === 200 ? '#4CAF50' : '#f44336';
        const req = log.req || {};
        const res = log.res || {};
        // 关键修复：解析嵌套两层的 data 结构
        const resData = res.data?.data || {};
        const logKeywords = (req.params?.personality || '').replace(/\s+/g, '');
        const personalityId = personalityMap[logKeywords] || '未知人格';

        return `
            <div class="record-card" data-index="${start + idx}">
                <div class="record-header">
                    <span>名称：${personalityId}</span>
                    <span>时间：${log.time}</span>
                    <span>令牌：${formatAuth(req.params?.Authorization)}</span>
                    <span style="background:${color};color:#fff;padding:2px 8px;border-radius:12px;">${code}</span>
                </div>
                <div class="record-details" style="display:none;">
                    <div class="record-section"><strong>=== 请求参数 ===</strong>
                        <div class="record-param"><span>请求时间：</span>${req.time || '无'}</div>
                        <div class="record-param"><span>请求IP：</span>${req.ip || '无'}</div>
                        <div class="record-param"><span>人格名称：</span>${personalityId}</div>
                        <div class="record-param"><span>人格关键词：</span>${req.params?.personality || '无'}</div>
                        <div class="record-param"><span>生成模型：</span>${req.params?.model || '无'}</div>
                        <div class="record-param"><span>图片尺寸：</span>${req.params?.size || '无'}</div>
                        <div class="record-param"><span>原始Prompt：</span>${req.params?.prompt || '无'}</div>
                    </div>
                    <div class="record-section"><strong>=== 响应参数 ===</strong>
                        <div class="record-param"><span>状态码：</span><span style="color:${color}">${code}</span></div>
                        <div class="record-param"><span>响应时间：</span>${res.time || '无'}</div>
                        <div class="record-param"><span>优化后Prompt：</span>${resData.refined_prompt || '无'}</div>
                        <div class="record-param"><span>图片Gitee地址：</span><a href="${resData.gitee_url || '#'}" target="_blank">点击查看</a></div>
                        <div class="record-param"><span>图片本地地址：</span><a href="${resData.local_url || '#'}" target="_blank">点击查看</a></div>
                        <div class="record-param"><span>响应人格：</span>${resData.personality || '无'}</div>
                        <div class="record-param"><span>聊天记录：</span>${resData.chat_record || '无'}</div>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    // 渲染分页按钮
    recordsList.innerHTML += `
        <div style="display:flex;justify-content:center;align-items:center;margin-top:20px;gap:8px;">
            <button onclick="changePage(${currentPage - 1})" ${currentPage === 1 ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''}>上一页</button>
            <span>第 ${currentPage} / ${totalPages} 页</span>
            <button onclick="changePage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''}>下一页</button>
        </div>
    `;

    // 绑定详情展开/收起事件
    document.querySelectorAll('.record-card').forEach(card => {
        card.addEventListener('click', () => {
            const details = card.querySelector('.record-details');
            details.style.display = details.style.display === 'block' ? 'none' : 'block';
        });
    });
};



// 分页切换函数
const changePage = (page) => {
    const totalPages = Math.ceil(logsData.length / pageSize);
    if (page < 1 || page > totalPages) return;
    currentPage = page;
    renderRecords();
};
window.changePage = changePage;

// 封装拉取主页数据 - 保留原有功能，适配JSON日志
const fetchHomeData = async (apiKey) => {
    const homeCards = document.getElementById('homeCards');
    homeCards.innerHTML = `
        <div style="margin-bottom:15px;text-align:right;">
            <button id="refreshHomeBtn" style="padding:6px 12px;border:none;background:#2196F3;color:#fff;border-radius:4px;cursor:pointer;">拉取最新数据</button>
        </div>
        <div id="balanceCard" class="card"><h3>账户余额</h3><p>查询中...</p></div>
        <div id="personCountCard" class="card"><h3>云端人格数量</h3><p>查询中...</p></div>
        <div id="todayTotalCard" class="card"><h3>今日调用</h3><p>统计中...</p></div>
        <div id="recentLogCard" class="card"><h3>最近3条日志</h3><ul id="recentLogList"></ul></div>
    `;

    document.getElementById('refreshHomeBtn').addEventListener('click', () => {
        clearCache();
        fetchHomeData(apiKey);
    });

    const timestamp = clearCache();
    try {
        if (apiKey) {
            const controller = new AbortController();
            setTimeout(() => controller.abort(), 15000);
            const res = await fetch(`/api/miyao.php?key=${apiKey}&t=${timestamp}`, { signal: controller.signal });
            const result = await res.json();
            document.getElementById('balanceCard').innerHTML = `<h3>账户余额</h3><p>剩余：${result?.data?.details?.[0]?.balance.toFixed(2) || '未知'}</p>`;
        } else throw new Error('无API密钥');
    } catch (err) {
        document.getElementById('balanceCard').innerHTML = `<h3>账户余额</h3><p style="color:red;">${err.message}</p>`;
    }

    try {
        const res = await fetch(`personality.json?t=${timestamp}`);
        const personalities = await res.json();
        document.getElementById('personCountCard').innerHTML = `<h3>云端人格数量</h3><p>共 ${Object.keys(personalities || {}).length} 个</p>`;
    } catch (err) {
        document.getElementById('personCountCard').innerHTML = `<h3>云端人格数量</h3><p style="color:red;">读取失败</p>`;
    }

    try {
        // 拉取JSON日志统计今日调用
        const res = await fetch(`request.json?t=${timestamp}`);
        if (!res.ok) throw new Error('日志文件不存在');
        const logJson = await res.json();
        logsData = parseLogs(logJson);
        const today = new Date().toLocaleDateString();
        const todayLogs = logsData.filter(l => new Date(l.time).toLocaleDateString() === today);
        document.getElementById('todayTotalCard').innerHTML = `<h3>今日调用</h3><p>${todayLogs.length} 次</p>`;
        document.getElementById('recentLogList').innerHTML = logsData.slice(0, 3).map(l => 
            `<li style="color:${l.success ? 'green' : 'red'}">${l.time} | ${l.success ? '成功(200)' : `失败(${l.res?.code || '未知'})`}</li>`
        ).join('') || '<li>暂无日志</li>';
    } catch (err) {
        document.getElementById('todayTotalCard').innerHTML = `<h3>今日调用</h3><p style="color:red;">${err.message}</p>`;
        document.getElementById('recentLogList').innerHTML = `<li style="color:red;">日志解析失败</li>`;
    }
};

// 渲染主页 - 保留
const renderHome = async apiKey => {
    clearCache();
    await fetchHomeData(apiKey);
};

// 渲染配置 - 保留
const renderConfig = async () => {
    const timestamp = clearCache();
    try {
        const res = await fetch(`config.json?t=${timestamp}`);
        if (!res.ok) throw new Error('配置读取失败');
        const config = await res.json();
        const apiKey = config?.main_proxy?.api_key || '';
        document.getElementById('configForm').innerHTML = `
            <div class="config-section"><h3>主代理配置</h3>
                <div class="form-group"><label>请求地址</label><input id="mainUrl" value="${config.main_proxy?.request_url || ''}"></div>
                <div class="form-group"><label>API密钥</label><input id="mainKey" value="${apiKey}"></div>
                <div class="form-group"><label>模型名称</label><input id="mainModel" value="${config.main_proxy?.model_name || ''}"></div>
            </div>
            <div class="config-section"><h3>基础参数</h3>
                <div class="form-row">
                    <div class="form-group"><label>最大历史消息</label><input type="number" id="maxHistory" value="${config.config_params?.max_history_messages || 20}"></div>
                    <div class="form-group"><label>图像步数</label><input type="number" id="imgSteps" value="${config.config_params?.image_steps || 50}"></div>
                    <div class="form-group"><label>引导度</label><input step="0.1" id="guideScale" value="${config.config_params?.guidance_scale || 7.5}"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>图片尺寸</label><input id="imgSize" value="${config.config_params?.image_size || '1024x1024'}"></div>
                    <div class="form-group"><label>超时(秒)</label><input type="number" id="timeout" value="${config.config_params?.request_timeout || 30}"></div>
                </div>
            </div>
            <div class="config-section"><h3>润色模型</h3>
                <div class="form-group"><label>请求地址</label><input id="polishUrl" value="${config.polish_model?.request_url || ''}"></div>
                <div class="form-group"><label>API密钥</label><input id="polishKey" value="${config.polish_model?.api_key || ''}"></div>
                <div class="form-group"><label>模型名称</label><input id="polishModel" value="${config.polish_model?.model_name || ''}"></div>
                <div class="form-row">
                    <div class="form-group"><label>超时(秒)</label><input type="number" id="polishTimeout" value="${config.polish_model?.request_timeout || 15}"></div>
                    <div class="form-group"><label>润色关键词</label><input id="polishKw" value="${config.polish_model?.polish_keywords || '通顺,生动,简洁'}"></div>
                </div>
            </div>
            <button class="save-btn" onclick="saveConfig()">保存配置</button>
        `;
        localStorage.setItem('apiKey', apiKey);
        renderHome(apiKey);
        renderPersonalities();
    } catch (err) {
        document.getElementById('configForm').innerHTML = `<p style="color:red;">${err.message}</p>`;
        renderHome('');
        renderPersonalities();
    }
};

// 渲染人格 - 保留
const renderPersonalities = async () => {
    const personalityList = document.getElementById('personalityList');
    const timestamp = clearCache();
    try {
        const res = await fetch(`personality.json?t=${timestamp}`);
        if (!res.ok) throw new Error('人格数据读取失败');
        const personalities = await res.json();
        // 遍历人格ID（Object.keys 得到的就是 "苏" 这类ID）
        personalityList.innerHTML = Object.keys(personalities || {}).map(name => {
            const p = personalities[name];
            return `
                <div class="personality-item">
                    <!-- 这里的 name 就是人格ID，直接展示 -->
                    <h3>${name} <button class="save-btn" style="padding:4px 12px;font-size:0.8rem;" onclick="updatePersonality('${name}')">保存修改</button></h3>
                    <div class="personality-details">
                        <div class="detail-item"><label>创建时间：</label>${p.timestamp || '未知'}</div>
                        <div class="detail-item"><label>Token：</label>${p.token || '无'}</div>
                        <div class="detail-item"><label>原始描述：</label><textarea id="original_${name}" rows="3" style="width:100%;padding:8px;border:1px solid #ddd;">${p.original_content || ''}</textarea></div>
                        <div class="detail-item"><label>提取关键词：</label><input id="keywords_${name}" value="${p.extracted_keywords || ''}" style="width:100%;padding:8px;border:1px solid #ddd;"></div>
                        <div class="detail-item"><label>最后更新：</label><span id="update_${name}">${p.update_time || '未知'}</span></div>
                    </div>
                </div>
            `;
        }).join('');
    } catch (err) {
        personalityList.innerHTML = `<p style="color:red;">${err.message}</p>`;
    }
};


// 保存配置 - 保留
const saveConfig = async () => {
    try {
        const newConfig = {
            main_proxy: { 
                request_url: document.getElementById('mainUrl').value, 
                api_key: document.getElementById('mainKey').value, 
                model_name: document.getElementById('mainModel').value 
            },
            config_params: { 
                max_history_messages: parseInt(document.getElementById('maxHistory').value) || 20, 
                image_steps: parseInt(document.getElementById('imgSteps').value) || 50, 
                guidance_scale: parseFloat(document.getElementById('guideScale').value) || 7.5, 
                image_size: document.getElementById('imgSize').value || '1024x1024', 
                request_timeout: parseInt(document.getElementById('timeout').value) || 30 
            },
            polish_model: { 
                request_url: document.getElementById('polishUrl').value, 
                api_key: document.getElementById('polishKey').value, 
                model_name: document.getElementById('polishModel').value, 
                request_timeout: parseInt(document.getElementById('polishTimeout').value) || 15, 
                polish_keywords: document.getElementById('polishKw').value || '通顺,生动,简洁' 
            }
        };
        await fetch('save_config.php', { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify(newConfig) 
        });
        alert('配置保存成功');
        localStorage.setItem('apiKey', newConfig.main_proxy.api_key);
        clearCache();
        renderHome(newConfig.main_proxy.api_key);
    } catch (err) { 
        alert(`保存失败：${err.message}`); 
    }
};

// 更新人格 - 保留
const updatePersonality = async name => {
    try {
        const res = await fetch('personality.json');
        const personalities = await res.json();
        if (!personalities[name]) throw new Error('人格不存在');
        personalities[name] = { 
            ...personalities[name], 
            original_content: document.getElementById(`original_${name}`).value.trim(), 
            extracted_keywords: document.getElementById(`keywords_${name}`).value.trim(), 
            update_time: new Date().toLocaleString('zh-CN').replace(/\//g, '-') 
        };
        await fetch('/api/save_personality.php', { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify(personalities) 
        });
        document.getElementById(`update_${name}`).textContent = personalities[name].update_time;
        alert(`人格「${name}」保存成功`);
        clearCache();
        renderHome(localStorage.getItem('apiKey'));
    } catch (err) { 
        alert(`保存失败：${err.message}`); 
    }
};

// 初始化 - 保留
window.onload = renderConfig;
