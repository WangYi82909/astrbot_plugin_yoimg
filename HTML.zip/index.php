<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>插件管理面板</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <button class="mobile-menu-btn" id="mobileMenuBtn">☰</button>

        <nav class="sidebar" id="sidebar">
            <ul>
                <li><a href="#home" class="active">1. 主页</a></li>
                <li><a href="#personality">2. 人格管理</a></li>
                <li><a href="#config">3. 站点配置</a></li>
                <li><a href="#records">4. 请求记录</a></li>
             
            </ul>
        </nav>

        <main class="main-content" id="mainContent">
            <section id="home" class="page-section active">
                <h1 class="page-title">---主页</h1>
                <div class="cards-grid" id="homeCards">
                    <!-- 卡片将由JavaScript动态生成 -->
                </div>
            </section>

            <section id="personality" class="page-section">
                <h1 class="page-title">---人格管理</h1>
                <div class="personality-list" id="personalityList"></div>
            </section>

            <section id="config" class="page-section">
                <h1 class="page-title">---站点配置</h1>
                <div class="config-form" id="configForm"></div>
            </section>

            <section id="records" class="page-section">
                <h1 class="page-title">---请求记录</h1>
                <div class="records-list" id="recordsList"></div>
            </section>
        </main>
    </div>

    <script src="script.js"></script>
</body>
</html>