<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => 'Method not allowed']);
    exit;
}

$configFile = 'config.json';

// 核心修改：读取JSON请求体，替代 $_POST
$rawData = file_get_contents('php://input');
$postData = json_decode($rawData, true);
if (!$postData) {
    echo json_encode(['code' => 400, 'message' => '无效的JSON数据']);
    exit;
}

// 初始化配置结构
$config = [
    'main_proxy' => [],
    'config_params' => [],
    'polish_model' => []
];
if (file_exists($configFile)) {
    $oldConfig = json_decode(file_get_contents($configFile), true);
    if ($oldConfig) {
        $config = array_merge_recursive($config, $oldConfig);
    }
}

// 直接从JSON数据中提取配置，与JS的newConfig结构一一对应
// 1. main_proxy 配置
if (isset($postData['main_proxy'])) {
    $config['main_proxy'] = array_merge($config['main_proxy'], $postData['main_proxy']);
}
// 2. config_params 配置
if (isset($postData['config_params'])) {
    $config['config_params'] = array_merge($config['config_params'], $postData['config_params']);
}
// 3. polish_model 配置
if (isset($postData['polish_model'])) {
    $config['polish_model'] = array_merge($config['polish_model'], $postData['polish_model']);
}

// 保存配置
if (file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
    echo json_encode(['code' => 200, 'message' => '配置保存成功', 'data' => $config]);
} else {
    echo json_encode(['code' => 500, 'message' => '保存失败，请检查目录写入权限']);
}
?>
