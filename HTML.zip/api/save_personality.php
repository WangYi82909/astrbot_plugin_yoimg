<?php
header('Content-Type: application/json');
// 接收POST的JSON数据
$json = file_get_contents('php://input');
$personality = json_decode($json, true);

if ($personality && is_array($personality)) {
    // 写入personality.json
    $result = file_put_contents('../personality.json', json_encode($personality, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    if ($result) {
        echo json_encode(['code' => 200, 'msg' => '保存成功']);
    } else {
        echo json_encode(['code' => 500, 'msg' => '文件写入失败，请检查权限']);
    }
} else {
    echo json_encode(['code' => 400, 'msg' => '无效的人格数据']);
}
?>
