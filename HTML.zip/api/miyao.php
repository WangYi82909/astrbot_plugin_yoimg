<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf-8");

$k = $_GET['key'] ?? '';
if (empty($k)) die(json_encode(['code'=>400,'msg'=>'参数错误：key不能为空','data'=>null]));

$ch = curl_init('https://ai.gitee.com/v1/tokens/packages/balance');
curl_setopt_array($ch,[
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_HTTPHEADER => ["Authorization: Bearer {$k}","Content-Type: application/json"],
    CURLOPT_TIMEOUT => 10,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_SSL_VERIFYHOST => 0
]);

$res = curl_exec($ch);
$err = curl_errno($ch);
curl_close($ch);

if ($err) {
    echo json_encode(['code'=>500,'msg'=>"请求失败：{$err}",'data'=>null]);
} else {
    $data = json_decode($res,true);
    echo json_encode(['code' => json_last_error() ? 400 : 200,
                     'msg' => json_last_error() ? '响应解析失败' : '查询成功',
                     'data' => json_last_error() ? null : $data]);
}
